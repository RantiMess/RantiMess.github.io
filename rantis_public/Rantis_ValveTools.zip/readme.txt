Extract the folder to your documents/maya/2012/prefs/shelves folder
The tools will only work if you launch Maya with runmaya.bat