These rigs should work for maya 2012 and above 
Hide the models joints by unticking the joints checkbox from your viewpoers Show menu.
When exporting to dmx select the group named "group" in the outliner and preform an export selected.

You are free to use this rig for whatever you like, feel free to credit me. :)