import vs

#==================================================================================================
def AddValidObjectToList( objectList, obj ):
    if ( obj != None ): objectList.append( obj )
    

#==================================================================================================
def HideControlGroups( rig, rootGroup, *groupNames ):
    for name in groupNames:    
        group = rootGroup.FindChildByName( name, False )
        if ( group != None ):
            rig.HideControlGroup( group )

    
#==================================================================================================
# Create the reverse foot control and operators for the foot on the specified side
#==================================================================================================
def CreateReverseFoot( controlName, sideName, gameModel, animSet, shot, helperControlGroup, footControlGroup ) :
    
    # Cannot create foot controls without heel position, so check for that first
    heelAttachName = "pvt_heel_" + sideName
    if ( gameModel.FindAttachment( heelAttachName ) == 0 ):
        print "Could not create foot control " + controlName + ", model is missing heel attachment point: " + heelAttachName;
        return None
    
    footRollDefault = 0.5
    rotationAxis = vs.Vector( 1, 0, 0 )
        
    # Construct the name of the dag nodes of the foot and toe for the specified side
    footName = "rig_foot_" + sideName
    toeName = "rig_toe_" + sideName    
    
    # Get the world space position and orientation of the foot and toe
    footPos = sfm.GetPosition( footName )
    footRot = sfm.GetRotation( footName )
    toePos = sfm.GetPosition( toeName )
    
    # Setup the reverse foot hierarchy such that the foot is the parent of all the foot transforms, the 
    # reverse heel is the parent of the heel, so it can be used for rotations around the ball of the 
    # foot that will move the heel, the heel is the parent of the foot IK handle so that it can perform
    # rotations around the heel and move the foot IK handle, resulting in moving all the foot bones.
    # root
    #   + rig_foot_R
    #       + rig_knee_R
    #       + rig_reverseHeel_R
    #           + rig_heel_R
    #               + rig_footIK_R
    
  
    # Construct the reverse heel joint this will be used to rotate the heel around the toe, and as
    # such is positioned at the toe, but using the rotation of the foot which will be its parent, 
    # so that it has no local rotation once parented to the foot.
    reverseHeelName = "rig_reverseHeel_" + sideName
    reverseHeelDag = sfm.CreateRigHandle( reverseHeelName, pos=toePos, rot=footRot, rotControl=False )
    sfmUtils.Parent( reverseHeelName, footName, vs.REPARENT_LOGS_OVERWRITE )
    
    
    
    # Construct the heel joint, this will be used to rotate the foot around the back of the heel so it 
    # is created at the heel location (offset from the foot) and also given the rotation of its parent.
    heelName = "rig_heel_" + sideName
    vecHeelPos = gameModel.ComputeAttachmentPosition( heelAttachName )
    heelPos = [ vecHeelPos.x, vecHeelPos.y, vecHeelPos.z ]     
    heelRot = sfm.GetRotation( reverseHeelName )
    heelDag = sfm.CreateRigHandle( heelName, pos=heelPos, rot=heelRot, posControl=True, rotControl=False )
    sfmUtils.Parent( heelName, reverseHeelName, vs.REPARENT_LOGS_OVERWRITE )
    
    # Create the ik handle which will be used as the target for the ik chain for the leg
    ikHandleName = "rig_footIK_" + sideName   
    ikHandleDag = sfmUtils.CreateHandleAt( ikHandleName, footName )
    sfmUtils.Parent( ikHandleName, heelName, vs.REPARENT_LOGS_OVERWRITE )
                    
    # Create an orient constraint which causes the toe's orientation to match the foot's orientation
    footRollControlName = controlName + "_" + sideName
    toeOrientTarget = sfm.OrientConstraint( footName, toeName, mo=True, controls=False )
    footRollControl, footRollValue = sfmUtils.CreateControlledValue( footRollControlName, "value", vs.AT_FLOAT, footRollDefault, animSet, shot )
    
    # Create the expressions to re-map the footroll slider value for use in the constraint and rotation operators
    toeOrientExprName = "expr_toeOrientEnable_" + sideName    
    toeOrientExpr = sfmUtils.CreateExpression( toeOrientExprName, "inrange( footRoll, 0.5001, 1.0 )", animSet )
    toeOrientExpr.SetValue( "footRoll", footRollDefault )
    
    toeRotateExprName = "expr_toeRotation_" + sideName
    toeRotateExpr = sfmUtils.CreateExpression( toeRotateExprName, "max( 0, (footRoll - 0.5) ) * 140", animSet )
    toeRotateExpr.SetValue( "footRoll", footRollDefault )
                            
    heelRotateExprName = "expr_heelRotation_" + sideName
    heelRotateExpr = sfmUtils.CreateExpression( heelRotateExprName, "max( 0, (0.5 - footRoll) ) * -100", animSet )
    heelRotateExpr.SetValue( "footRoll", footRollDefault )
        
    # Create a connection from the footroll value to all of the expressions that require it
    footRollConnName = "conn_footRoll_" + sideName
    footRollConn = sfmUtils.CreateConnection( footRollConnName, footRollValue, "value", animSet )
    footRollConn.AddOutput( toeOrientExpr, "footRoll" )
    footRollConn.AddOutput( toeRotateExpr, "footRoll" )
    footRollConn.AddOutput( heelRotateExpr, "footRoll" )
    
    # Create the connection from the toe orientation enable expression to the target weight of the 
    # toe orientation constraint, this will turn the constraint on an off based on the footRoll value
    toeOrientConnName = "conn_toeOrientExpr_" + sideName;
    toeOrientConn = sfmUtils.CreateConnection( toeOrientConnName, toeOrientExpr, "result", animSet )
    toeOrientConn.AddOutput( toeOrientTarget, "targetWeight" )
    
    # Create a rotation constraint to drive the toe rotation and connect its input to the 
    # toe rotation expression and connect its output to the reverse heel dag's orientation
    toeRotateConstraintName = "rotationConstraint_toe_" + sideName
    toeRotateConstraint = sfmUtils.CreateRotationConstraint( toeRotateConstraintName, rotationAxis, reverseHeelDag, animSet )
    
    toeRotateExprConnName = "conn_toeRotateExpr_" + sideName
    toeRotateExprConn = sfmUtils.CreateConnection( toeRotateExprConnName, toeRotateExpr, "result", animSet )
    toeRotateExprConn.AddOutput( toeRotateConstraint, "rotations", 0 );

    # Create a rotation constraint to drive the heel rotation and connect its input to the 
    # heel rotation expression and connect its output to the heel dag's orientation 
    heelRotateConstraintName = "rotationConstraint_heel_" + sideName
    heelRotateConstraint = sfmUtils.CreateRotationConstraint( heelRotateConstraintName, rotationAxis, heelDag, animSet )
    
    heelRotateExprConnName = "conn_heelRotateExpr_" + sideName
    heelRotateExprConn = sfmUtils.CreateConnection( heelRotateExprConnName, heelRotateExpr, "result", animSet )
    heelRotateExprConn.AddOutput( heelRotateConstraint, "rotations", 0 )
    
    if ( helperControlGroup != None ):
        sfmUtils.AddDagControlsToGroup( helperControlGroup, reverseHeelDag, ikHandleDag, heelDag )       
    
    if ( footControlGroup != None ):
        footControlGroup.AddControl( footRollControl )
        
    return ikHandleDag


#==================================================================================================
# Compute the direction from boneA to boneB
#==================================================================================================
def ComputeVectorBetweenBones( boneA, boneB, scaleFactor ):
    
    vPosA = vs.Vector( 0, 0, 0 )
    boneA.GetAbsPosition( vPosA )
    
    vPosB = vs.Vector( 0, 0, 0 )
    boneB.GetAbsPosition( vPosB )
    
    vDir = vs.Vector( 0, 0, 0 )
    vs.mathlib.VectorSubtract( vPosB, vPosA, vDir )
    vDir.NormalizeInPlace()
    
    vScaledDir = vs.Vector( 0, 0, 0 )
    vs.mathlib.VectorScale( vDir, scaleFactor, vScaledDir )    
    
    return vScaledDir
    
   
#==================================================================================================
# Build a simple ik rig for the currently selected animation set
#==================================================================================================
def BuildRig():
    
    # Get the currently selected animation set and shot
    shot = sfm.GetCurrentShot()
    animSet = sfm.GetCurrentAnimationSet()
    gameModel = animSet.gameModel
    rootGroup = animSet.GetRootControlGroup()
    
    # Start the biped rig to which all of the controls and constraints will be added
    rig = sfm.BeginRig( "rig_biped_" + animSet.GetName() );
    if ( rig == None ):
        return
    
    # Change the operation mode to passthrough so changes chan be made temporarily
    sfm.SetOperationMode( "Pass" )
    
    # Move everything into the reference pose
    sfm.SelectAll()
    sfm.SetReferencePose()
    
    #==============================================================================================
    # Find the dag nodes for all of the bones in the model which will be used by the script
    #==============================================================================================
    boneRoot      = sfmUtils.FindFirstDag( [ "RootTransform" ], True )
    boneCOG      = sfmUtils.FindFirstDag( [ "COG" ], True )
    boneMidSeg    = sfmUtils.FindFirstDag( [ "MiddleSegment" ], True )
    boneBckSeg    = sfmUtils.FindFirstDag( [ "BackSegment" ], True )
    boneFntSeg    = sfmUtils.FindFirstDag( [ "FrontSegment" ], True )
    boneYJnt      = sfmUtils.FindFirstDag( [ "BandY_Joint" ], True )
    boneBrowBase  = sfmUtils.FindFirstDag( [ "Brow_Base" ], True )
    boneBrowR     = sfmUtils.FindFirstDag( [ "R_brow" ], True )
    boneBrowL     = sfmUtils.FindFirstDag( [ "L_brow" ], True )
    boneBrowM     = sfmUtils.FindFirstDag( [ "Middle_brow" ], True )
    boneCore      = sfmUtils.FindFirstDag( [ "Outer_Core" ], True )
    boneEye       = sfmUtils.FindFirstDag( [ "Eye" ], True )
    boneIris      = sfmUtils.FindFirstDag( [ "Iris" ], True )
    boneShieldB   = sfmUtils.FindFirstDag( [ "Shield_Base" ], True ) 
    boneShieldU   = sfmUtils.FindFirstDag( [ "Upper_Shield" ], True ) 
    boneShieldMid = sfmUtils.FindFirstDag( [ "Middle_Shield" ], True )
    boneShieldL   = sfmUtils.FindFirstDag( [ "Lower_Shield" ], True ) 
    boneLidBase   = sfmUtils.FindFirstDag( [ "LidBase" ], True )
    boneLLC1 	  = sfmUtils.FindFirstDag( [ "Lower_Lid_Compress1" ], True )
    boneLLC2      = sfmUtils.FindFirstDag( [ "Lower_Lid_Compress2" ], True )
    boneLLM       = sfmUtils.FindFirstDag( [ "Lower_Lid_Main" ], True ) 
    boneULC1 	  = sfmUtils.FindFirstDag( [ "Upper_Lid_Compress1" ], True )
    boneULC2      = sfmUtils.FindFirstDag( [ "Upper_Lid_Compress2" ], True )
    boneULM       = sfmUtils.FindFirstDag( [ "Upper_Lid_Main" ], True ) 
    boneFLThrust  = sfmUtils.FindFirstDag( [ "FrontLeft_Thruster" ], True )        
    boneFRThrust  = sfmUtils.FindFirstDag( [ "FrontRight_Thruster" ], True )
    boneBLThrust  = sfmUtils.FindFirstDag( [ "BackLeft_Thruster" ], True )        
    boneBRThrust  = sfmUtils.FindFirstDag( [ "BackRight_Thruster" ], True )

    #==============================================================================================
    # Create the rig handles and constrain them to existing bones
    #==============================================================================================
    rigRoot       = sfmUtils.CreateConstrainedHandle( "rig_root",         boneRoot,      bCreateControls=False )
    rigCOG       = sfmUtils.CreateConstrainedHandle( "rig_COG",           boneCOG,       bCreateControls=False )
    rigMidSeg    = sfmUtils.CreateConstrainedHandle( "rig_MiddleSegment", boneMidSeg,    bCreateControls=False )
    rigBckSeg    = sfmUtils.CreateConstrainedHandle( "rig_BackSegment",   boneBckSeg,    bCreateControls=False )
    rigFntSeg    = sfmUtils.CreateConstrainedHandle( "rig_FrontSegment",  boneFntSeg,    bCreateControls=False )
    rigYJnt      = sfmUtils.CreateConstrainedHandle( "rig_BandY_Joint",   boneYJnt,      bCreateControls=False )
    rigBrowBase  = sfmUtils.CreateConstrainedHandle( "rig_Brow_Base",     boneBrowBase,  bCreateControls=False )
    rigBrowR     = sfmUtils.CreateConstrainedHandle( "rig_R_brow",        boneBrowR,     bCreateControls=False )
    rigBrowL     = sfmUtils.CreateConstrainedHandle( "rig_L_brow",        boneBrowL,     bCreateControls=False )
    rigBrowM     = sfmUtils.CreateConstrainedHandle( "rig_Middle_brow",   boneBrowM,     bCreateControls=False )
    rigCore      = sfmUtils.CreateConstrainedHandle( "rig_Outer_Core",    boneCore,      bCreateControls=False )
    rigEye       = sfmUtils.CreateConstrainedHandle( "rig_Eye",           boneEye,       bCreateControls=False )
    rigIris      = sfmUtils.CreateConstrainedHandle( "rig_Iris",          boneIris,      bCreateControls=False )
    rigShieldB   = sfmUtils.CreateConstrainedHandle( "rig_Shield_Base",   boneShieldB,   bCreateControls=False ) 
    rigShieldU   = sfmUtils.CreateConstrainedHandle( "rig_Upper_Shield",  boneShieldU,   bCreateControls=False ) 
    rigShieldMid   = sfmUtils.CreateConstrainedHandle( "rig_Middle_Shield", boneShieldMid,   bCreateControls=False ) 
    rigShieldL   = sfmUtils.CreateConstrainedHandle( "rig_Lower_Shield",  boneShieldL,   bCreateControls=False ) 
    rigLidBase   = sfmUtils.CreateConstrainedHandle( "rig_LidBase",                 boneLidBase, bCreateControls=False )
    rigLLC1 	 = sfmUtils.CreateConstrainedHandle( "rig_Lower_Lid_Compress1",     boneLLC1,    bCreateControls=False )
    rigLLC2      = sfmUtils.CreateConstrainedHandle( "rig_Lower_Lid_Compress2",     boneLLC2,    bCreateControls=False )
    rigLLM       = sfmUtils.CreateConstrainedHandle( "rig_Lower_Lid_Main",          boneLLM,     bCreateControls=False ) 
    rigULC1 	 = sfmUtils.CreateConstrainedHandle( "rig_Upper_Lid_Compress1",     boneULC1,    bCreateControls=False )
    rigULC2      = sfmUtils.CreateConstrainedHandle( "rig_Upper_Lid_Compress2",     boneULC2,    bCreateControls=False )
    rigULM       = sfmUtils.CreateConstrainedHandle( "rig_Upper_Lid_Main",          boneULM,     bCreateControls=False ) 
    rigFLThrust  = sfmUtils.CreateConstrainedHandle( "rig_FrontLeft_Thruster",      boneFLThrust,    bCreateControls=False )        
    rigFRThrust  = sfmUtils.CreateConstrainedHandle( "rig_FrontRight_Thruster",     boneFRThrust,    bCreateControls=False )
    rigBLThrust  = sfmUtils.CreateConstrainedHandle( "rig_BackLeft_Thruster",       boneBLThrust,    bCreateControls=False )        
    rigBRThrust  = sfmUtils.CreateConstrainedHandle( "rig_BackRight_Thruster",      boneBRThrust,    bCreateControls=False )
        
    
    # Create a list of all of the rig dags
    allRigHandles = [ rigRoot, rigCOG, rigMidSeg, rigBckSeg, rigFntSeg,
                      rigYJnt, rigBrowBase, rigBrowR, rigBrowL, rigBrowM,
                      rigCore, rigEye, rigIris,
                      rigShieldB, rigShieldU, rigShieldMid, rigShieldL,
                      rigLidBase, rigLLC1, rigLLC2, rigLLM, rigULC1, rigULC2, rigULM,
                      rigFLThrust, rigBLThrust,
                      rigFRThrust, rigBRThrust ];
    
    
    #==============================================================================================
    # Generate the world space logs for the rig handles and remove the constraints
    #==============================================================================================
    sfm.ClearSelection()
    sfmUtils.SelectDagList( allRigHandles )
    sfm.GenerateSamples()
    sfm.RemoveConstraints()    
    
    
    #==============================================================================================
    # Build the rig handle hierarchy
    #==============================================================================================
    sfmUtils.ParentMaintainWorld( rigCOG,        rigRoot )
    sfmUtils.ParentMaintainWorld( rigMidSeg,     rigCOG )
    sfmUtils.ParentMaintainWorld( rigBckSeg,     rigMidSeg )
    sfmUtils.ParentMaintainWorld( rigFntSeg,     rigMidSeg )
    sfmUtils.ParentMaintainWorld( rigYJnt,       rigFntSeg )
    sfmUtils.ParentMaintainWorld( rigBrowBase,   rigYJnt )
    sfmUtils.ParentMaintainWorld( rigBrowR,      rigBrowBase )
    sfmUtils.ParentMaintainWorld( rigBrowL,      rigBrowBase )
    sfmUtils.ParentMaintainWorld( rigBrowM,      rigBrowBase )
    sfmUtils.ParentMaintainWorld( rigCore,       rigFntSeg )
    sfmUtils.ParentMaintainWorld( rigEye,        rigCore )
    sfmUtils.ParentMaintainWorld( rigIris,       rigEye )
    sfmUtils.ParentMaintainWorld( rigShieldB,    rigFntSeg )
    sfmUtils.ParentMaintainWorld( rigShieldU,    rigShieldB )
    sfmUtils.ParentMaintainWorld( rigShieldMid,    rigShieldB )
    sfmUtils.ParentMaintainWorld( rigShieldL,    rigShieldB )
    sfmUtils.ParentMaintainWorld( rigLidBase,    rigCore )
    sfmUtils.ParentMaintainWorld( rigLLC1,       rigLidBase )
    sfmUtils.ParentMaintainWorld( rigLLC2,       rigLidBase )
    sfmUtils.ParentMaintainWorld( rigLLM,        rigLidBase )
    sfmUtils.ParentMaintainWorld( rigULC1,       rigLidBase )
    sfmUtils.ParentMaintainWorld( rigULC2,       rigLidBase )
    sfmUtils.ParentMaintainWorld( rigULM,        rigLidBase )
    sfmUtils.ParentMaintainWorld( rigFLThrust,   rigMidSeg )
    sfmUtils.ParentMaintainWorld( rigBLThrust,   rigBckSeg )
    sfmUtils.ParentMaintainWorld( rigFRThrust,   rigMidSeg )
    sfmUtils.ParentMaintainWorld( rigBRThrust,   rigBckSeg )

    # Set the defaults of the rig transforms to the current locations. Defaults are stored in local
    # space, so while the parent operation tries to preserve default values it is cleaner to just
    # set them once the final hierarchy is constructed.
    sfm.SetDefault()
    
	
    #==============================================================================================
    # Create constraints to drive the bone transforms using the rig handles
    #==============================================================================================
    
    # The following bones are simply constrained directly to a rig handle
    sfmUtils.CreatePointOrientConstraint( rigRoot,     boneRoot       )
    sfmUtils.CreatePointOrientConstraint( rigCOG,      boneCOG        )
    sfmUtils.CreatePointOrientConstraint( rigMidSeg,   boneMidSeg     )
    sfmUtils.CreatePointOrientConstraint( rigBckSeg,   boneBckSeg     )
    sfmUtils.CreatePointOrientConstraint( rigFntSeg,   boneFntSeg     )
    sfmUtils.CreatePointOrientConstraint( rigYJnt,     boneYJnt       )
    sfmUtils.CreatePointOrientConstraint( rigBrowBase, boneBrowBase   )
    sfmUtils.CreatePointOrientConstraint( rigBrowR,    boneBrowR      )
    sfmUtils.CreatePointOrientConstraint( rigBrowL,    boneBrowL      )
    sfmUtils.CreatePointOrientConstraint( rigBrowM,    boneBrowM      )
    sfmUtils.CreatePointOrientConstraint( rigCore,     boneCore       )
    sfmUtils.CreatePointOrientConstraint( rigEye,      boneEye        )
    sfmUtils.CreatePointOrientConstraint( rigIris,     boneIris       )
    sfmUtils.CreatePointOrientConstraint( rigShieldB,  boneShieldB    )   
    sfmUtils.CreatePointOrientConstraint( rigShieldU,  boneShieldU    ) 
    sfmUtils.CreatePointOrientConstraint( rigShieldMid,  boneShieldMid    ) 
    sfmUtils.CreatePointOrientConstraint( rigShieldL,  boneShieldL    )
    sfmUtils.CreatePointOrientConstraint( rigLidBase,  boneLidBase    )
    sfmUtils.CreatePointOrientConstraint( rigLLC1,     boneLLC1       )
    sfmUtils.CreatePointOrientConstraint( rigLLC2,     boneLLC2       )
    sfmUtils.CreatePointOrientConstraint( rigLLM,      boneLLM        ) 
    sfmUtils.CreatePointOrientConstraint( rigULC1,     boneULC1       )
    sfmUtils.CreatePointOrientConstraint( rigULC2,     boneULC2       )
    sfmUtils.CreatePointOrientConstraint( rigULM,      boneULM        ) 
    sfmUtils.CreatePointOrientConstraint( rigFLThrust, boneFLThrust   )        
    sfmUtils.CreatePointOrientConstraint( rigFRThrust, boneFRThrust   )
    sfmUtils.CreatePointOrientConstraint( rigBLThrust, boneBLThrust   )        
    sfmUtils.CreatePointOrientConstraint( rigBRThrust, boneBRThrust   )
    

    #==============================================================================================
    # Re-organize the selection groups
    #==============================================================================================  
    rigMainGroup = rootGroup.CreateControlGroup( "RigMain" )
    rigHeadGroup = rootGroup.CreateControlGroup( "RigHead" )
    rigThrusterGroup = rootGroup.CreateControlGroup( "RigThrusters" )
    rigLThrusterGroup = rootGroup.CreateControlGroup( "L_Thrusters" )
    rigRThrusterGroup = rootGroup.CreateControlGroup( "R_Thrusters" )
    ShieldGroup = rootGroup.CreateControlGroup( "Shields" )
    BrowGroup = rootGroup.CreateControlGroup( "Brow" )
    LidGroup = rootGroup.CreateControlGroup( "Lids" )
    sfmUtils.AddDagControlsToGroup( rigMainGroup, rigRoot, rigCOG, rigMidSeg, rigBckSeg, rigFntSeg )
    rigMainGroup.AddChild( ShieldGroup )
    sfmUtils.AddDagControlsToGroup( ShieldGroup, rigShieldB, rigShieldU, rigShieldMid, rigShieldL )
    sfmUtils.AddDagControlsToGroup( rigHeadGroup, rigYJnt, rigCore, rigEye, rigIris )
    rigHeadGroup.AddChild( BrowGroup )
    rigHeadGroup.AddChild( LidGroup )
    sfmUtils.AddDagControlsToGroup( BrowGroup, rigBrowBase, rigBrowR, rigBrowL, rigBrowM )
    sfmUtils.AddDagControlsToGroup( LidGroup, rigLidBase, rigLLC1, rigLLC2, rigLLM, rigULC1, rigULC2, rigULM )
    rigThrusterGroup.AddChild( rigLThrusterGroup )
    rigThrusterGroup.AddChild( rigRThrusterGroup )	
    sfmUtils.AddDagControlsToGroup( rigLThrusterGroup, rigFLThrust, rigBLThrust )
    sfmUtils.AddDagControlsToGroup( rigRThrusterGroup, rigFRThrust, rigBRThrust )
	
    # Set the control group visiblity, this is done through the rig so it can track which
    # groups it hid, so they can be set back to being visible when the rig is detached.
    HideControlGroups( rig, rootGroup, "Body", "Arms", "Legs", "Unknown", "Other", "Root" )      
        
    #Re-order the groups
    fingersGroup = rootGroup.FindChildByName( "Fingers", False ) 
    rootGroup.MoveChildToBottom( rigMainGroup )
    rootGroup.MoveChildToBottom( rigHeadGroup )    
    rootGroup.MoveChildToBottom( rigThrusterGroup )      
    rootGroup.MoveChildToBottom( fingersGroup )  
       
    rightFingersGroup = rootGroup.FindChildByName( "RightFingers", True ) 
    if ( rightFingersGroup != None ):
        rigRThrusterGroup.AddChild( rightFingersGroup )
        rightFingersGroup.SetSelectable( False )
                                
    leftFingersGroup = rootGroup.FindChildByName( "LeftFingers", True ) 
    if ( leftFingersGroup != None ):
        rigLThrusterGroup.AddChild( leftFingersGroup )
        leftFingersGroup.SetSelectable( False )
        

    #==============================================================================================
    # Set the selection groups colors
    #==============================================================================================
    topLevelColor = vs.Color( 0, 128, 255, 255 )
    RightColor = vs.Color( 225, 143, 55, 255 )
    LeftColor = vs.Color( 7, 156, 226, 255 )
    Color1 = vs.Color( 255, 255, 153, 255 )
    Color2 = vs.Color( 204, 153, 255, 255 )
    
    rigMainGroup.SetGroupColor( topLevelColor, False )
    rigHeadGroup.SetGroupColor( topLevelColor, False )
    rigThrusterGroup.SetGroupColor( topLevelColor, False )
    ShieldGroup.SetGroupColor( topLevelColor, False )
    BrowGroup.SetGroupColor( Color1, False )
    LidGroup.SetGroupColor( Color2, False )
    rigLThrusterGroup.SetGroupColor( LeftColor, False )
    rigRThrusterGroup.SetGroupColor( RightColor, False )
    
    
    # End the rig definition
    sfm.EndRig()
    return
    
#==================================================================================================
# Script entry
#==================================================================================================

# Construct the rig for the selected animation set
BuildRig();


    
    




