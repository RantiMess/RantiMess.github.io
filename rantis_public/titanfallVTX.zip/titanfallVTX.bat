@ECHO OFF
SET "fname=*.dx11.vtx"
FOR %%i IN ("%fname%") DO FOR /f "delims=." %%j IN ("%%i") DO ren "%%~i" "%%~j%%~xi"
xcopy "*.vtx" "*.vt2"
rename "*.vtx" "*.dx90.vtx"
rename "*.vt2" "*.dx80.vtx"